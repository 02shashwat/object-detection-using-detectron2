# player identification > 2023-07-21 11:51am
https://universe.roboflow.com/celebal-technologies-0wlpt/player-identification-lwn8m

Provided by a Roboflow user
License: CC BY 4.0

